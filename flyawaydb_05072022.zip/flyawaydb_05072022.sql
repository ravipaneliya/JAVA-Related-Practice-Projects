CREATE DATABASE  IF NOT EXISTS `flyawaydb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `flyawaydb`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: flyawaydb
-- ------------------------------------------------------
-- Server version	5.7.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking_details`
--

DROP TABLE IF EXISTS `booking_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_details` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `flight_id` int(10) NOT NULL,
  `booking_class` enum('Economy','Premium','Business') NOT NULL,
  `travel_date` date NOT NULL,
  `no_of_passanger` int(2) NOT NULL,
  `total_fare` decimal(8,2) NOT NULL,
  `booking_status` tinyint(1) DEFAULT '1' COMMENT '1-Pending, 0-Expired/Cancelled',
  `customer_id` int(10) NOT NULL,
  `booking_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `flight_id` (`flight_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `booking_details_ibfk_1` FOREIGN KEY (`flight_id`) REFERENCES `flight_details` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `booking_details_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_details`
--

LOCK TABLES `booking_details` WRITE;
/*!40000 ALTER TABLE `booking_details` DISABLE KEYS */;
INSERT INTO `booking_details` VALUES (1,5,'Premium','2022-07-07',3,3900.00,1,1,'2022-07-02 16:10:03'),(2,5,'Premium','2022-07-07',3,3900.00,1,1,'2022-07-02 16:16:30'),(3,5,'Premium','2022-07-07',3,3900.00,1,1,'2022-07-02 16:20:08'),(4,5,'Premium','2022-07-07',3,3900.00,1,1,'2022-07-02 16:20:48'),(5,1,'Business','2022-07-27',2,4000.00,1,1,'2022-07-03 11:09:03'),(6,7,'Business','2022-07-21',3,4800.00,1,2,'2022-07-03 15:00:42'),(7,9,'Premium','2022-07-14',7,11200.00,1,6,'2022-07-03 15:18:28'),(8,11,'Economy','2022-07-14',5,6000.00,1,16,'2022-07-05 15:20:01'),(9,1,'Premium','2022-07-29',3,3600.00,1,1,'2022-07-05 15:42:35'),(10,4,'Premium','2022-07-15',5,6000.00,1,18,'2022-07-05 16:08:55');
/*!40000 ALTER TABLE `booking_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `is_admin` tinyint(1) DEFAULT '0' COMMENT '1-admin, 0-customer',
  `email` varchar(50) NOT NULL,
  `password_string` varchar(20) NOT NULL,
  `phoneno` char(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Smit Paneliya',1,'smit@hr.com','12','9876543210'),(2,'James Butt',0,'jb@gm.com','12','5048451427'),(3,'Art Venere',0,'art@venere.org','ab123','8562644130'),(4,'Donette Foller',0,'donette.foller@cox.net','ab123','5135494561'),(5,'Simona Morasca',1,'sm@mr.co','ab123','4198006759'),(6,'Leota Dilliard',0,'leota@hotmail.com','ab123','4088131105'),(7,'Sage Wieser',0,'sage_wieser@cox.net','ab123','6057944895'),(8,'Kris Marrier',0,'kris@gmail.com','ab123','4108044694'),(9,'Abel Maclead',0,'amaclead@gmail.com','ab123','6316773675'),(10,'Graciela Ruta',1,'gruta@cox.net','ab123','4405797763'),(11,'Cammy Albares',0,'calbares@gmail.com','ab123','9568417216'),(12,'Mattie Poquette',0,'mattie@aol.com','ab123','6029536360'),(13,'Meaghan Garufi',1,'mg@hm.com','ab123','9312357959'),(14,'Yuki Whobrey',0,'yuki_whobrey@aol.com','ab123','3133414470'),(15,'Fletcher Flosi',0,'fletcher.flosi@yahoo.com','ab123','8154265657'),(16,'Danial',0,'dan@gm.co','111','0123456789'),(17,'James Kott',0,'jk@gm.a','123','4561237890'),(18,'Tom Jerry',0,'tj@ct.co','123','7845125623');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flight_details`
--

DROP TABLE IF EXISTS `flight_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flight_details` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `flight_number` int(6) NOT NULL,
  `airline` enum('AIR-INDIA','INDIGO','SPICE-JET','GO-AIR') NOT NULL,
  `weekdays` varchar(200) NOT NULL,
  `src_airport_code` char(6) NOT NULL,
  `dest_airport_code` char(6) NOT NULL,
  `economy_fare` decimal(8,2) DEFAULT NULL,
  `premium_fare` decimal(8,2) DEFAULT NULL,
  `business_fare` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flight_details`
--

LOCK TABLES `flight_details` WRITE;
/*!40000 ALTER TABLE `flight_details` DISABLE KEYS */;
INSERT INTO `flight_details` VALUES (1,1001,'AIR-INDIA','0,1,2,3,5','SRT','BOM',1000.00,1200.00,2000.00),(2,1002,'INDIGO','1,3,5','SRT','AMD',1100.00,1400.00,2300.00),(3,1003,'SPICE-JET','0,2,4,6','BOM','SRT',700.00,900.00,1200.00),(4,1004,'GO-AIR','0,1,2','BAR','AMD',1000.00,1200.00,1800.00),(5,1005,'AIR-INDIA','3,4,5,6','SRT','DEL',1100.00,1300.00,2000.00),(6,1006,'SPICE-JET','0,1,4,5','AMD','BOM',800.00,1000.00,1400.00),(7,1007,'GO-AIR','4,5,6','SRT','BAR',900.00,1100.00,1600.00),(8,1008,'INDIGO','2,4,5','BOM','DEL',1200.00,1400.00,2200.00),(9,1009,'SPICE-JET','1,2,4','BAR','BOM',1400.00,1600.00,2600.00),(10,1010,'GO-AIR','0,3,5','DEL','BAR',1300.00,1500.00,2400.00),(11,1012,'INDIGO','2,6','SRT','BAR',1200.00,NULL,NULL),(13,1055,'GO-AIR','','SRT','AMD',1000.00,1500.00,2500.00);
/*!40000 ALTER TABLE `flight_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-05 21:49:04
